
public class Emplyoee {
	int Id;
	String Name;
	String City;
	long Sal;
	@Override
	public String toString() {
		return "Emplyoee [Id=" + Id + ", Name=" + Name + ", City=" + City + ", Sal=" + Sal + "]";
	}


	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public long getSal() {
		return Sal;
	}
	public void setSal(long sal) {
		Sal = sal;
	}
	

}
