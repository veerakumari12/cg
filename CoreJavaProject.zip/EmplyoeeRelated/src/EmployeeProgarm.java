import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.stream.Collectors;

public class EmployeeProgarm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Emplyoee> EmplyoeeList = new ArrayList<>();
		createEmployeeList(EmplyoeeList);
		
	Map<String, List<Emplyoee>> map=EmplyoeeList.stream().collect(Collectors.groupingBy(Emplyoee::getName));
		System.out.println(EmplyoeeList.stream().collect(Collectors.groupingBy(Emplyoee::getId)));
		
		
		map.forEach((Key, Value) -> System.out.println(Key + "" + "" + Value));
		
		//EmplyoeeList.stream().reduce(Emplyoee::getId,Emplyoee::getName );
		
		Map<String, Optional<Emplyoee>> reduceByCityAvgGrade = EmplyoeeList.stream()
			    .collect(Collectors
			             .groupingBy(Emplyoee::getCity,
			             Collectors.reducing(BinaryOperator
			                                 .maxBy(Comparator
			                                          .comparing(Emplyoee::getId)))));
		
		System.out.println(reduceByCityAvgGrade);
	}

	private static void createEmployeeList(List<Emplyoee> EmplyoeeList) {
		Emplyoee e1 = new Emplyoee();
		e1.setId(10);
		e1.setName("a");
		e1.setCity("hyd");
		e1.setSal(1000);

		Emplyoee e2 = new Emplyoee();
		e2.setId(20);
		e2.setName("b");
		e2.setCity("chenai");
		e2.setSal(2000);

		Emplyoee e3 = new Emplyoee();
		e3.setId(30);
		e3.setName("c");
		e3.setCity("mumbai");
		e3.setSal(3000);

		Emplyoee e4 = new Emplyoee();
		e4.setId(40);
		e4.setName("d");
		e4.setCity("rajsthan");
		e4.setSal(4000);

		EmplyoeeList.add(e1);
		EmplyoeeList.add(e2);
		EmplyoeeList.add(e3);
		EmplyoeeList.add(e4);
		
		System.out.println(EmplyoeeList);

	}

}
