package com.java.array;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class java8Streams {

	public static void main(String[] args) {
    //merge the two lists  and save to one list.
       List<Integer> list1=Arrays.asList(1,2,3,4);
       List<Integer> list2=Arrays.asList(1,6,3,7);
       List<Integer> list3=Stream.concat(list1.stream(),list2.stream())
    		   .collect(Collectors.toList());
       System.out.println(list3);
      //remove the douplicates from list.
       
       List<Integer> removeDuplicates=list3.stream().distinct().collect(Collectors.toList());
System.out.println("   "+removeDuplicates);
String s1="mani";
String s2="kumari";
if(s1==s2) {
	System.out.println("true");
}

//in given >50;
//what is stream api why

//can I customized sort in hashset.
//write a query highest salary in each department

//horizantal scale and vertical scalling.
//consumer,bypredicate,supplier.
//spring security
//executer framwork


	}

}
