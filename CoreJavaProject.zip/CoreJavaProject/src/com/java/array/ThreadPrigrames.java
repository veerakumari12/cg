package com.java.array;

public class ThreadPrigrames extends Thread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ThreadPrigrames ThreadPrigrames=new ThreadPrigrames();
		ThreadPrigrames.start();
		System.out.println("hello   --------->");
	}

}
