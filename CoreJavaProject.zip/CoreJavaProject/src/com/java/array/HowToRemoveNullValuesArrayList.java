package com.java.array;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class HowToRemoveNullValuesArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      List<String> list1=new ArrayList();
      List<String> removenull=new ArrayList();
      list1.add("");
      list1.add(null);
      list1.add("a");
      list1.add("a");
      list1.add("a");
      list1.add("b");
      System.out.println(list1);
      for(String list:list1) {
    	  if(list!=null) {
    		  removenull.add(list);
    	  }
    	  
      }
      System.out.println(removenull);
      list1.stream().filter(x->x!=null).forEach(x->System.out.println(x));
      list1.stream().distinct().filter(x->x!=null).forEach(x->System.out.println(x));
      list1.stream().distinct().
      filter(x->x!=null).sorted(Comparator.reverseOrder()).forEach(x->System.out.println(x));
      list1.stream().distinct().
      filter(x->x!=null).sorted().forEach(x->System.out.println(x));
      list1.stream().distinct().filter(x->x!=null).map(y->y.toUpperCase()).
      forEach(y->System.out.println(y));
      
      list1.stream().limit(4).forEach(x->System.out.println(x));
      list1.stream().skip(4).forEach(x->System.out.println(x));
     String a1= list1.stream().reduce((a,b)->a+b).get();    
     System.out.println(a1);
     long a3=list1.stream().count();
     System.out.println(a3);
     //list1.stream().filter(x->x).forEach(x->System.out.println(x));
  System.out.println(list1.stream().toArray().toString());  
  
  
	}

}
