package com.java.array;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SecondHihestArrayjava8 {
	public static void main(String[] args) {
		int [] arr= {2,4,7,8,9};
		
	List<Integer> integerList=Arrays.stream(arr).boxed().
			sorted(Comparator.reverseOrder()).collect(Collectors.toList());				
		System.out.println(integerList);
		Integer secondhighest=	Arrays.stream(arr).boxed().
		sorted(Comparator.reverseOrder())
		.skip(3)
		.findFirst()
		.get();
		System.out.println("secondhighest"+secondhighest);
		
		Integer listvalue=	Arrays.stream(arr).boxed().
				sorted()			
				.findFirst()
				.get();
		System.out.println("listvalue"+listvalue);
		
		
	}

}
