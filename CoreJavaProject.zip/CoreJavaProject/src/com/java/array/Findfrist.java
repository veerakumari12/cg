package com.java.array;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Findfrist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   List<String> list1=new ArrayList();		     
		      list1.add("hello");
		      list1.add("jjjj");
		      list1.add("a");
		      list1.add("asdsad");
		      list1.add("aewqeqwewq");
		      list1.add("b");
		      System.out.println(list1.stream().findFirst().get());
		      System.out.println(list1.stream().findAny().get());
		      
		System.out.println(list1.stream().anyMatch(x->x.startsWith("a")));  
		
		list1.stream().filter(x->x.startsWith("a"))
				.forEach(x->System.out.println(x));
	}

}
