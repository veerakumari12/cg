package com.java.array;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class HowToRemoveDuplicateFromList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> list1=new ArrayList<>();
		List<String> uniqucklist1=new ArrayList<>();
		list1.add("a");
		list1.add("a");
		list1.add("c");
		list1.add("a");
		for(String list:list1) {
			if(!uniqucklist1.contains(list)) {
				uniqucklist1.add(list);
			}
					
		}
		System.out.println(uniqucklist1);
		list1.stream().distinct().forEach(list->System.out.println(list)
		);
		
		List<Integer> list2=new ArrayList<>();
		list2.add(1);
		list2.add(2);
		list2.add(3);
		list2.add(4);
		list2.add(5);
		Optional<Integer> minelememt=list2.stream().min((a1,a2)->a1.compareTo(a2));
		System.out.println(minelememt);
		
		Optional<Integer> Maxelememt=list2.stream().max((a1,a2)->a1.compareTo(a2));
		System.out.println(Maxelememt);
		
		
	}
	
	

}
