package com.java.array;

public interface B {
	public void a1();

}
