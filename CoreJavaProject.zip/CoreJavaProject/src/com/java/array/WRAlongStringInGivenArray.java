package com.java.array;

public class WRAlongStringInGivenArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
