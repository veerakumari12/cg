package com.java.array;

import java.util.Arrays;

public class ArrayLenth {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = { 1, 2,7,8,9, 4, 5 };
		System.out.println(a.length);

		// conver Arrays into Stream.
		long a1 = Arrays.stream(a).count();
		System.out.println(a1);

		// iterate array
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);

		}
		// conver Arrays into Stream
		Arrays.stream(a).forEach(x -> System.out.println(x));
		

		int [] arr= {2,7,9,12,15,19};
		int taget=11;
		
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr.length;j++) {
				if(arr[i]+arr[j]==taget) {
				int ee=	(arr[i],arr[j]);
					System.out.println();
					
					
				}
			}
			
			
		}

	}
}
