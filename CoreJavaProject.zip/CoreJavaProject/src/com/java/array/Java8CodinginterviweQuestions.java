package com.java.array;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Java8CodinginterviweQuestions {

	public static void main(String[] args) {
		//write java program count the occurence of give String.
		
		String input="helloworld";
		
	String[] a=	input.split("");
	System.out.println(Arrays.toString(a));
	Map<String,List<String>> map=Arrays.stream(input.split("")).collect(Collectors.groupingBy(s->s));
	System.out.println(map);	
		//count the each charachter 
	 Map<String, Long> counting=	Arrays.stream(input.split(""))
	.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()) );
     System.out.println(counting);
    //display duplicate letter only.
     
   List<String> onlyduplicateelements=Arrays.stream(input.split(""))
     .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
    		 .entrySet().stream()
    		 .filter(x->x.getValue()>1)
    		 .map(Map.Entry::getKey)
    		 .collect(Collectors.toList());
   
   System.out.println("onlyduplicateelements"+onlyduplicateelements);
   
   
   //write a java program to find first non-repeat elememt from a given string.
   
   String onlyduplicateelements1=Arrays.stream(input.split(""))
		     .collect(Collectors.groupingBy(Function.identity(),LinkedHashMap::new,Collectors.counting()))
		    		 .entrySet().stream()
		    		 .filter(x->x.getValue()==1)
		    		 .findFirst()
		    		 .get().getKey();
   System.out.println(onlyduplicateelements1);
		    		
		    		 
   
   
   
	}

}
