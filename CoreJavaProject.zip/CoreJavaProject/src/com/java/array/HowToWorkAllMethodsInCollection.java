package com.java.array;

import java.util.ArrayList;

public class HowToWorkAllMethodsInCollection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String s1="D-Doll";
		
	ArrayList<String>  a1=new ArrayList<String>();
	a1.add("A-Apple");
	a1.add("B-Ball");
	a1.add("C-Cat");
	a1.add("D-Doll");
	a1.add("E-Egg");	
	a1.hashCode();
	a1.iterator();
	System.out.println(a1 +"hashcode"+a1.hashCode()+a1.iterator());
	
	
	ArrayList<String>  a2=new ArrayList<String>();
	a2.add("a");
	a2.add("b");
	a2.add("c");
	a2.add("d");
	a2.add("e");	
	System.out.println(a2);
	
	if(a1.containsAll(a2)) {
		System.out.println(true);
	}else {
		System.out.println(false);
	}
	
	if(s1.equals(a1.get(3))) {
		System.out.println(true);
	}else {
		System.out.println(false);
	}
	
	}

}
