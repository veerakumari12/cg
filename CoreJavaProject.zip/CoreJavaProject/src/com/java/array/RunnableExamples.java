package com.java.array;

public class RunnableExamples implements Runnable {
	public void run() {
		System.out.println("hello         ------------------");
		
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RunnableExamples runnableExamples=new RunnableExamples();
	Thread t =new Thread(runnableExamples);
	t.start();
	}

	
	
}
