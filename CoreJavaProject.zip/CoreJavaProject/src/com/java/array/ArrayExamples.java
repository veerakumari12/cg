package com.java.array;

import java.util.ArrayList;

public class ArrayExamples {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer b=0;
		Integer c=0;
		ArrayList<Integer> list1=new ArrayList<Integer>();
		list1.add(1);
		ArrayList<Integer> list2=new ArrayList<Integer>();
		list2.add(2);
		
		ArrayList<Integer> list3=new ArrayList<Integer>();
		
		for(Integer l1:list1) {
			 b=l1;	
		}
		for(Integer l2:list2) {
		c=l2;
		}
		
		list3.add(b);
	
		list3.add(c);
		System.out.println(list3);
		}
		
		
	}


