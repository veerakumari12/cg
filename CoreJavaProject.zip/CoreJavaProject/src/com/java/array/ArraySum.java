package com.java.array;

import java.util.Arrays;
import java.util.OptionalDouble;

public class ArraySum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {10,20,30,60};
		int sum=0;
		for(int i=0;i<a.length;i++) {
			sum=sum+a[i];			
		}
System.out.println(sum);
//Convets java8
int a1=Arrays.stream(a).sum();
System.out.println(a1);
OptionalDouble a2=Arrays.stream(a).average();
Arrays.stream(a).max();
System.out.println(Arrays.stream(a).max());
System.out.println(Arrays.stream(a).min());
	}
	

}
