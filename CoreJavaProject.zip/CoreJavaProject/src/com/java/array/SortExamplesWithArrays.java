package com.java.array;

import java.util.Arrays;

public class SortExamplesWithArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []a= {10,20,50,30,50,90,80};
		//Arrays.sort(a);
		//System.out.println(a);
		Arrays.stream(a).sorted().forEach(x->System.out.println(x));
		Arrays.stream(a).sorted().distinct().forEach(x->System.out.println(x));
		
	}

}
