package com.java.array;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MapExamples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String>  map=new HashMap();
		map.put(1, "a");
		map.put(6, "b");
		map.put(3, "b");
		map.put(4, "c");
		map.put(5, "d");
		
		//System.out.println(map);
		for(Map.Entry<Integer,String> entry :map.entrySet()) {
		System.out.println(entry.getKey());	
		System.out.println(entry.getValue());
		}
		map.entrySet().stream().forEach(x->System.out.println(x.getValue()));
		map.entrySet().stream().forEach(x->System.out.println(x.getKey()));
		map.keySet().stream().forEach(x->System.out.println(x));
		map.values().stream().forEach(x->System.out.println(x));;
//sort the data based on acending order to key
		map.keySet().stream().sorted().forEach(x->System.out.println(x));
		//desending order
		map.keySet().stream().sorted(Comparator.reverseOrder()).forEach(x->System.out.println(x));
		
		map.entrySet().stream().sorted().
		forEach(x->System.out.println(x));
		
		//Convert map to list.
		
	List<Integer>a=map.keySet().stream().collect(Collectors.toList());
	
	System.out.println(a);
	

		
	}

}
