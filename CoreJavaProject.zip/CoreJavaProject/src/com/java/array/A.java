package com.java.array;

public interface A {

	public void a1();
}
