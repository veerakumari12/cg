package com.java.array;

public class C implements A,B {

	@Override
	public void a1() {
		// TODO Auto-generated method stub
		System.out.println("aaaaaa");
	}
public static void main(String[] args) {
	A a=new C();
	a.a1();
	
	B b=new C();
	b.a1();
}
}
