package com.java.array;

import java.util.Arrays;
import java.util.Comparator;

public class EvenNumberInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]= {1,2,3,4,5,6,6,5};
		for(int i=0;i<a.length;i++) {
			if(a[i]%2==0) {
				System.out.println("it even number"+a[i]);
			}/*else {
				System.out.println("it not even number"+a[i]);	
			}*/
		}
	System.out.println(Arrays.stream(a).distinct());		
Arrays.stream(a).filter(x->x%2==0 ).forEach(x->System.out.println(x));
Arrays.stream(a).count();
System.out.println(Arrays.stream(a).count());
System.out.println(Arrays.stream(a).max());
System.out.println(Arrays.stream(a).min());
System.out.println(Arrays.stream(a).boxed().sorted().findFirst().get());
System.out.println(Arrays.stream(a).boxed().sorted().skip(4).
		findFirst().get());

System.out.println(Arrays.stream(a).boxed().sorted(Comparator.reverseOrder()).skip(1).
		findFirst().get());
Arrays.stream(a).distinct().forEach(x->System.out.println(x));
Arrays.stream(a).average();
System.out.println(Arrays.stream(a).average());
int minelemnt=Arrays.stream(a).min().getAsInt();
System.out.println(minelemnt);
int maxelemnt=Arrays.stream(a).max().getAsInt();
System.out.println(maxelemnt);
	}

}
