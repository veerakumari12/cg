package com.java.array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class java8 {
	
	
	public static void printCities() {
	    
	    List<String> cities = new ArrayList<>();
	    cities.add("Delhi");
	    cities.add("Mumbai");
	    cities.add("Goa");
	    cities.add("Pune");
	    
	    Consumer<String> printConsumer= city-> System.out.println(city);    
	  /*  cities.forEach(printConsumer);*/
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printCities();
		int[] a= {1,2,3,4,5,6,7};
		int s=0;
	for(int i=0;i<a.length;i++) {
		
		s=s+a[i];
		System.out.println(s);
		
		
	}
	
	
	  Stream.iterate(1, element->element+1)  
      .filter(element->element%5==0)  
      .limit(5)  
      .forEach(System.out::println);  
	  
	  Consumer<String> printConsumer = t -> System.out.println(t);
	    Stream<String> cities = Stream.of("Sydney", "Dhaka", "New York", "London");
	    cities.forEach(printConsumer);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	}
	
	
	
	
	
	
	
	


