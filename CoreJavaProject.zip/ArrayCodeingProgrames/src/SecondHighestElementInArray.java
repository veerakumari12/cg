import java.util.Arrays;
import java.util.Comparator;

public class SecondHighestElementInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [] a= {1,3,5,20,6,17};


Arrays.stream(a).sorted().skip(1);
System.out.println(Arrays.stream(a).boxed().sorted(Comparator.reverseOrder()).skip(1).findFirst());
Arrays.sort(a);
System.out.println(a[a.length-1]);
System.out.println(a[a.length-2]);

	}

}
