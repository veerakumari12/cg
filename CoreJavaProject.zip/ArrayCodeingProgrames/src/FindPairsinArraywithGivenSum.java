
public class FindPairsinArraywithGivenSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 2, 3, 4, 5, 6, 7, 9 };

		int low = 0;
		int high = arr.length - 1;
		int sum = 8;

		while (low <high) {
			if (arr[low] + arr[high] > sum) {
				high--;
			} else if (arr[low] + arr[high] < sum) {
				low++;
			} else if (arr[low] + arr[high] == sum) {
				System.out.println(arr[low] +","+arr[high]);
				low++;
				high--;
			}
		}

	}

}
