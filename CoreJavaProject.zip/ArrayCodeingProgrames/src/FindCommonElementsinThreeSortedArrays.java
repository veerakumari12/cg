
public class FindCommonElementsinThreeSortedArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = { 1, 2, 3, 4, 5, 6 };
		int[] a1 = { 2, 4, 5, 6, 7 };
		int[] a2 = { 4, 5, 6, 7, 8 };
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a1.length; j++) {
				for (int k = 0; k < a2.length; k++) {
					if (a[i] == a1[j] && a1[j] == a2[k]) {
						System.out.println(a[i]);

					}

				}

			}

		}

	}

}
