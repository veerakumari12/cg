import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class duplicateElementInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []a= {1,2,3,1,2,4};
		
	Arrays.stream(a).distinct().forEach(x->System.out.println(x));
		Set<Integer> uniquicvalues=new HashSet();
		for(int i=0;i<a.length;i++) {
			if(!uniquicvalues.contains(a[i])) {
				
				uniquicvalues.add(a[i]);
				
			}
			
			
		}
		
		System.out.println(uniquicvalues);
	}

}
