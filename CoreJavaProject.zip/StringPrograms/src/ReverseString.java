
public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="hello";
char [] str1=str.toCharArray();
for(int i=str1.length-1;i>=0;i--) {
	System.out.println(str1[i]);
	
}

StringBuffer bf=new StringBuffer(str);
System.out.println(bf.reverse());
StringBuilder sb=new StringBuilder(str);
sb.reverse();


	}
	
}
